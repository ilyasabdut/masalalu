<?php $__env->startSection('content'); ?>
  <!-- Navigation-->
     <title><?php echo e(env('APP_NAME')); ?></title> 
      <div class="content-wrapper">
    <div class="container-fluid">
    
      
    <div class="row justify-content-center">
      <div class="col-sm-8">

         <?php echo csrf_field(); ?>

                            <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                            <?php endif; ?>

                            <?php if(session('error')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session('error')); ?>

                                </div>
                            <?php endif; ?>


     <div class="card">
        <div class="card-header">
          Import/Export
        </div>
        <div class="card-body">
          
           <a href="<?php echo e(URL::to('/exportmenu/')); ?>"><button class="btn btn-success">Export Excel xlsx</button></a>

           <form style="border: 4px solid #a1a1a1;margin-top: 15px;padding: 10px;"
             action="/importmenu"     class="form-horizontal" method="post"
             enctype="multipart/form-data">

              <?php echo csrf_field(); ?>

               <p style="color: red"><?php echo e($errors->first('file')); ?></p>

                <input type="file" name="file" />
             <button class="btn btn-primary">Import File</button>
              <a  class="btn btn-secondary" href="javascript:history.back()">
                                    <?php echo e(__('Back')); ?>

                                </a>

              </form>
        </div>
      </div>
    </div>
  </div>

</div>
</div>

 

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>